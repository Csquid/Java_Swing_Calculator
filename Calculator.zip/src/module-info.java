module TEST {
	requires java.desktop;
}